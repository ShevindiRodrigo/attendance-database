BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `student` (
	`studentregno`	varchar ( 20 ) NOT NULL,
	`studentname`	varchar ( 50 ) NOT NULL,
	`levelofstudy`	varchar ( 5 ) NOT NULL,
	`gender`	varchar ( 10 ) NOT NULL,
	`dateofbirth`	date NOT NULL,
	`address`	varchar ( 20 ) NOT NULL,
	`studpassword`	varchar ( 10 ) NOT NULL,
	PRIMARY KEY(`studentregno`)
);
INSERT INTO `student` (studentregno,studentname,levelofstudy,gender,dateofbirth,address,studpassword) VALUES ('2015CSC015','Isuri Kalugalla','S','Female','1994-10-02','Kegalla','123@sdd'),
 ('2015SP006','Madhusanka Kumara','G','Male','1994-05-27','Rathnapura','36678sff'),
 ('2015SP030','Robin Roy','S','Male','1993-04-16','Jaffna','45786xcv'),
 ('2015SP054','Malki Sandamini ','M','Female','1995-11-25','Anuradhapura','asdt34fhh'),
 ('2015SP128','Shevindi Rodrigo','M','Female','1995-11-27','Wennappuwa','12567dffxc');
CREATE TABLE IF NOT EXISTS `stud_course` (
	`studentregno`	varchar ( 20 ) NOT NULL,
	`courseid`	varchar ( 20 ) NOT NULL,
	FOREIGN KEY(`studentregno`) REFERENCES `student`(`studentregno`) ON DELETE CASCADE ON UPDATE NO ACTION,
	FOREIGN KEY(`courseid`) REFERENCES `course`(`courseid`) ON DELETE CASCADE ON UPDATE NO ACTION
);
INSERT INTO `stud_course` (studentregno,courseid) VALUES ('2015CSC015','CSC311SC2'),
 ('2015SP006','CSC311GC2'),
 ('2015SP030','CSC311GC2'),
 ('2015SP054','CSC311GC2'),
 ('2015SP128','CSC311GC2'),
 ('2015CSC015','CSC312SC2'),
 ('2015SP006','CSC312GC2'),
 ('2015SP030','CSC312GC2'),
 ('2015SP054','CSC312GC2'),
 ('2015SP128','CSC312GC2'),
 ('2015CSC015','CSC313SC3'),
 ('2015SP054','CSC313MC3'),
 ('2015SP128','CSC313MC3');
CREATE TABLE IF NOT EXISTS `stud_attendance` (
	`date`	date NOT NULL,
	`time`	time NOT NULL,
	`lectureid`	varchar ( 10 ) NOT NULL,
	`courseid`	varchar ( 20 ) NOT NULL,
	`studregno`	varchar ( 20 ) NOT NULL,
	`attendance`	varchar ( 10 ) NOT NULL,
	FOREIGN KEY(`courseid`) REFERENCES `course`(`courseid`) ON DELETE CASCADE ON UPDATE NO ACTION,
	FOREIGN KEY(`studregno`) REFERENCES `student`(`studentregno`) ON DELETE CASCADE ON UPDATE NO ACTION,
	PRIMARY KEY(`date`,`time`,`lectureid`,`courseid`,`studregno`),
	FOREIGN KEY(`lectureid`) REFERENCES `lecturer`(`lectureid`) ON DELETE CASCADE ON UPDATE NO ACTION
);
INSERT INTO `stud_attendance` (date,time,lectureid,courseid,studregno,attendance) VALUES ('2018-03-01','08:00:00','001','CSC311GC2','2015SP128','Present'),
 ('2018-03-02','08:00:00','002','CSC312GC2','2015SP128','Present'),
 ('2018-03-02','09:00:00','002','CSC311SC2','2015CSC015','Present'),
 ('2018-03-03','10:00:00','003','CSC313MC3','2015SP054','Absent'),
 ('2018-03-03','10:00:00','003','CSC313SC3','2015CSC015','Present');
CREATE TABLE IF NOT EXISTS `lecturer` (
	`lectureid`	varchar ( 20 ) NOT NULL,
	`lecturername`	varchar ( 20 ) NOT NULL,
	PRIMARY KEY(`lectureid`)
);
INSERT INTO `lecturer` (lectureid,lecturername) VALUES ('001','Dr.Mahesan'),
 ('002','Dr.Ramanan'),
 ('003','Dr.Barathy');
CREATE TABLE IF NOT EXISTS `lecpassword` (
	`lectureid`	varchar ( 20 ) NOT NULL,
	`lecpassword`	varchar ( 20 ) NOT NULL,
	FOREIGN KEY(`lectureid`) REFERENCES `lecturer`(`lectureid`) ON DELETE CASCADE ON UPDATE NO ACTION
);
INSERT INTO `lecpassword` (lectureid,lecpassword) VALUES ('001','xxxxx'),
 ('002','yyyyy'),
 ('003','rrrrrr');
CREATE TABLE IF NOT EXISTS `lec_course` (
	`lectureid`	INTEGER NOT NULL,
	`courseid`	varchar ( 50 ) NOT NULL,
	FOREIGN KEY(`lectureid`) REFERENCES `lecturer`(`lectureid`) ON DELETE CASCADE ON UPDATE NO ACTION,
	FOREIGN KEY(`courseid`) REFERENCES `course`(`courseid`) ON DELETE CASCADE ON UPDATE NO ACTION
);
INSERT INTO `lec_course` (lectureid,courseid) VALUES (1,'CSC311GC2'),
 (1,'CSC311SC2'),
 (2,'CSC312GC2'),
 (2,'CSC312SC2'),
 (3,'CSC313MC3'),
 (3,'CSC313SC3');
CREATE TABLE IF NOT EXISTS `course` (
	`courseid`	varchar ( 20 ) NOT NULL,
	`general`	tinyint ( 1 ) NOT NULL,
	`direct`	tinyint ( 1 ) NOT NULL,
	`special`	tinyint ( 1 ) NOT NULL,
	`coursetitle`	varchar ( 50 ) NOT NULL,
	PRIMARY KEY(`courseid`)
);
INSERT INTO `course` (courseid,general,direct,special,coursetitle) VALUES ('CSC311GC2',1,0,1,'RAD'),
 ('CSC311SC2',0,1,0,'RAD'),
 ('CSC312GC2',1,0,1,'Programming in Logic'),
 ('CSC312SC2',0,1,0,'Programming in Logic'),
 ('CSC313MC3',0,0,1,'DIP'),
 ('CSC313SC3',0,1,0,'DIP');
COMMIT;
